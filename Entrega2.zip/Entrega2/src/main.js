import Vue from 'vue' /*createApp, h,*/
import App from './App.vue'
import router from './router'
import './axios'
import store from './vuex'
const mongoose = require('mongoose');
const express = require('express');

const App = express();
mongoose.connect('')

//createApp(App).mount('#app')

Vue.config.productionTip = false


new Vue({
    router,
    store,
    render: h => h(App),


}).$mount('#app')