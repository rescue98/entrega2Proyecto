<template>

    <div>
        <h3 v-if="user"> Hola, {{ user.nombre }}</h3>
        <h3 v-if="!user"> No te encuentras registrado</h3>
    </div>

</template>


<script>

import { mapGetters } from 'vuex'

export default {
    name: 'Inicio',
    computed: {
        ...mapGetters(['user'])
    }
}

</script>