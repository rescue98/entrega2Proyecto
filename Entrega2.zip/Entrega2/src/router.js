import Vue from 'vue'
import Router from 'vue-router'
import Inicio from './components/Inicio.vue'
import Login from './components/Login.vue'
import Registro from './components/Registro.vue'

Vue.use(Router)

export default new Router({
    mode: 'history',
    routes: [
        { path: '/inicio', component: Inicio },
        { path: '/login', component: Login },
        { path: '/registro', component: Registro }
    ]
})