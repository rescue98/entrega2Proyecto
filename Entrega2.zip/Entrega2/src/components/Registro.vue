<template>
    <form @submit.prevent="handleSumit">
        <h3></h3>

        <div class="form-group">
            <label>Nombre</label>
            <input type="text" class="form-control" v-model="nombre" placeholder="Nombre" />
        </div>

        <div class="form-group">
            <label>Email</label>
            <input type="email" class="form-control" v-model="email" placeholder="Email" />
        </div>

        <div class="form-group">
            <label>Password</label>
            <input type="password" class="form-control" v-model="password" placeholder="Password" />
        </div>

        <div class="form-group">
            <label>Confirmar Password</label>
            <input type="password" class="form-control" v-model="confirmar_password" placeholder="Confirmar Password" />
        </div>

        <button class="btn btn-primary btn-block">Registrar</button>
    </form>

</template>



<script>
import axios from 'axios'
export default {
    name: 'Registro',
    data() {
        return {
            nombre: '',
            email: '',
            password: '',
            confirmar_password: ''
        }
    },
    methods: {
        async handleSumit() {
            await axios.post('registro', {
                nombre: this.nombre,
                email: this.email,
                password: this.password,
                confirmar_password: this.confirmar_password

            });

            this.$router.push('/login');

        }
    }
}
</script>