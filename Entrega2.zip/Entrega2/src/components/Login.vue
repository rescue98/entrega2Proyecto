<template>
    <form @submit.prevent="handleSubmit">
        <h3>Login</h3>

        <div class="form-group">
            <label>Nombre</label>
            <input type="nombre" class="form-control" v-model="email" placeholder="Nombre" />
        </div>

        <div class="form-group">
            <label>Clave</label>
            <input type="clave" class="form-control" v-model="password" placeholder="Clave" />
        </div>

        <button class="btn btn-primary btn-block">Login</button>

        <p>
            <router-link to="olvidado">¿Olvidaste tu password?</router-link>
        </p>
    </form>
</template>


<script>
import axios from 'axios'
export default {
    name: 'Login',
    data() {
        return {
            email: '',
            password: ''
        }
    },
    methods: {
        async handleSubmit() {
            const response = await axios.post('login', {
                email: this.email,
                password: this.password
            });

            localStorage, setItem('token', response.data.token);
            this.$store.dispatch('user', response.data.user);
            this.$router.push('/')

        }
    }
}
</script>